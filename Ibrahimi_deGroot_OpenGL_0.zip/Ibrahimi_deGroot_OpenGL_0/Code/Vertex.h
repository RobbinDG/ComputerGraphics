#ifndef VERTEX_H
#define VERTEX_H

struct Vertex {
    float x, y;
    float r, g, b;
};

#endif // VERTEX_H
